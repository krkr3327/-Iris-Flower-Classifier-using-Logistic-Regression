import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Set Streamlit page config
st.set_page_config(page_title="🌼 Iris Classifier", layout="wide")

st.title("🌸 Iris Flower Classifier using Logistic Regression")

# Load data
@st.cache_data
def load_data():
    column_names = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'species']
    df = pd.read_csv("iris.data", header=None, names=column_names)
    df.dropna(inplace=True)
    return df

df = load_data()

# Display dataset
with st.expander("📄 View Dataset"):
    st.dataframe(df, use_container_width=True)

# Split data
X = df.drop('species', axis=1)
y = df['species']

# Encode species
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

# Train model
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)

# Show model accuracy
st.markdown("---")
st.subheader("📈 Model Evaluation")
col1, col2 = st.columns(2)

with col1:
    st.metric("✅ Accuracy", f"{acc:.2f}")
    st.text("Classification Report:")
    st.text(classification_report(y_test, y_pred, target_names=le.classes_))

with col2:
    st.text("Confusion Matrix:")
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt="d", cmap="Purples", xticklabels=le.classes_, yticklabels=le.classes_)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    st.pyplot(fig)

# ----------------------------------
# 🌟 Prediction Form in Sidebar
# ----------------------------------
st.markdown("---")
st.sidebar.header("🔍 Predict New Sample")
st.subheader("🌿 Predict Iris Species from Flower Features")

sepal_length = st.sidebar.slider("Sepal Length", 4.0, 8.0, 5.1)
sepal_width = st.sidebar.slider("Sepal Width", 2.0, 4.5, 3.5)
petal_length = st.sidebar.slider("Petal Length", 1.0, 7.0, 1.4)
petal_width = st.sidebar.slider("Petal Width", 0.1, 2.5, 0.2)

if st.sidebar.button("🌸 Predict"):
    input_data = [[sepal_length, sepal_width, petal_length, petal_width]]
    prediction = model.predict(input_data)[0]
    predicted_species = le.inverse_transform([prediction])[0]
    
    st.success(f"🌺 The predicted species is: **{predicted_species}**")

# Optional comparison
st.markdown("---")
st.info("Tip: You can compare your prediction results with dataset statistics shown above!")

